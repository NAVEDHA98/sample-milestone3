package com.premium.stc.controller;

import com.premium.stc.model.*;

public interface UserController {
	 public User registerUser(User user) throws Exception;
	 public User updateUser(User user) throws Exception;

	 
}
